using System;
using System.Text.RegularExpressions;

public class Program {

  public static void Main(string[] args) {
    Console.WriteLine("Hello to simplified rpg!");
    Console.WriteLine("wpisz wielkość mapy - x, y. liczbami");
    int x=0;
    int y=0;
    int kroki=0;
    string tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                x = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
              
                }
    tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                y = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
               
                                }

    string[,] mapa = new string[x,y];
   
    for(int i=0; i<y; i++) {
      for(int j=0; j<x; j++) mapa[j,i] = " * ";
    }
        for(int i=0; i<y; i++) {
      for(int j=0; j<x; j++) Console.Write(mapa[j,i]);
      Console.WriteLine();
    }
        Console.WriteLine("wpisz koordy gracza - x, y. liczbami");
    int cx=0;
    int cy=0;
   tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                cx = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
              
                }
    tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                cy = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
                
                }
    cx--;
    cy--;
    mapa[cx,cy]=" W ";
    Console.Clear();
            for(int i=0; i<y; i++) {
      for(int j=0; j<x; j++) Console.Write(mapa[j,i]);
      Console.WriteLine();
    }
    //Create two dimensional array for basic board-like structure.
    ConsoleKey k = new ConsoleKey();
    //while(cx>=0 && cy>=0 && cy<y && cx<x){
      while(true){
      k=Console.ReadKey().Key;
      kroki++;
    if (k == ConsoleKey.W){
      mapa[cx,cy]=" . ";
      cy--;
      if (cy<0) break;
      mapa[cx,cy]=" W ";
    }    
    else if (k == ConsoleKey.S){
      mapa[cx,cy]=" . ";
      cy++;
      if (cy>=y) break;
      mapa[cx,cy]=" W ";
    }    
    else if (k == ConsoleKey.A){
      mapa[cx,cy]=" . ";
      cx--;
      if (cx<0) break;
      mapa[cx,cy]=" W ";
    }    
    else if (k == ConsoleKey.D){
      mapa[cx,cy]=" . ";
      cx++;
      if (cx>=x) break;
      mapa[cx,cy]=" W ";
    }
    Console.Clear();
    //if(cx<0||cy<0||cy>=y||cx>=x)
            for(int i=0; i<y; i++) {
      for(int j=0; j<x; j++) Console.Write(mapa[j,i]);
      Console.WriteLine();

            }}
            Console.Clear();
         Console.WriteLine("💀 💀 💀 spadłeś 💀 💀 💀");   
         Console.WriteLine("zrobione kroki: "+kroki);
    //Display board as an string matrix ex. 
    /*
      * * * * *
      * * * * * 
      * * * * * 
    */

    //Insert player representation into board ex. 
    /*
      * * * * *
      * p * * * 
      * * * * * 
    */

    //Use function Console.ReadKey(true) to fetch currently user pressed key, remember to assign function result to a variable then compare variable with expected key ex ;
    /*
      if (result.Key == ConsoleKey.W) 
         result is an variable storing object that containts specific key, you have to reach for Key name to compare with expected one ex. ConsoleKey.L or ConsoleKey.Y 
    */

    //Make program listen for specific key to move player according to expected directions for example result = Console.ReadKey() == ConsoleKey.D will make player move to the left 
    /*
      * * * * *
      * * P * * 
      * * * * * 
    */


    //Finally we have to ensure that player can move in every direction, anytime, unless player will stop the game ;) What else needs to be done to make game better?

    
  }

}